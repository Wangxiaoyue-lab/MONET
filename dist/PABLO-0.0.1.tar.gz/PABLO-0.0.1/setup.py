from setuptools import setup, find_packages

setup(
    name="PABLO",
    version="0.0.1",
    description='Python Analysis for Biological Labyrinthine Omics',
    packages=find_packages(),
    install_requires=[
        # List your package dependencies here
    ],
)
